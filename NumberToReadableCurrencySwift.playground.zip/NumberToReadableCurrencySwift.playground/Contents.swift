import UIKit

var str = "Hello, playground"


class NumberToWord
 
{
    private static let specialNames = [
        "",
        " thousand",
        " million",
        " billion",
        " trillion",
        " quadrillion",
        " quintillion"
    ]
    
    
    private static let tensNames = [
        "",
        " ten",
        " twenty",
        " thirty",
        " forty",
        " fifty",
        " sixty",
        " seventy",
        " eighty",
        " ninety"
    ]
    
    private static let numNames = [
        "",
        " one",
        " two",
        " three",
        " four",
        " five",
        " six",
        " seven",
        " eight",
        " nine",
        " ten",
        " eleven",
        " twelve",
        " thirteen",
        " fourteen",
        " fifteen",
        " sixteen",
        " seventeen",
        " eighteen",
        " nineteen"
    ]
    
    private func convertLessThanOneThousand(_ value: Int) -> String {
        var current = ""
        var number: Int = value
        
        if (number % 100 < 20) {
            current = NumberToWord.numNames[number % 100]
            number /= 100
        }
        else {
            current = NumberToWord.numNames[number % 10]
            number /= 10;
            
            current = NumberToWord.tensNames[number % 10] + current
            number /= 10
        }
        if (number == 0) {
            return current
        }
        return NumberToWord.numNames[number] + " hundred" + current
    }
    
    public func convert(_ value : Int64) -> String {
        print("sourceNumber = \(value)")

        if value == 0 { return "zero" }
        var number = value
        var prefix = ""
        var current = ""
        
        if number < 0 {
            number = -number
            prefix = "negative"
        }
        
        var place = 0
        
        repeat {
            let n = number % 1000
            if n != 0 {
                let s = convertLessThanOneThousand(Int(n))
                current = s + NumberToWord.specialNames[place] + current
            }
            place += 1
            number /= 1000
        } while number > 0
        
        return (prefix + current).trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

let obj = NumberToWord()
print(obj.convert(123456789))
print(obj.convert(-55))
print(obj.convert(0))
print(obj.convert(24))
print(obj.convert(555))
print(obj.convert(68345))
