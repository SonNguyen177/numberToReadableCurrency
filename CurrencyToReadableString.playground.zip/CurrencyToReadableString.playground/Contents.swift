import UIKit


func  NumericIntToString(_ pStrNumeric: String) -> String
{
    var strNumber = ""
    var strReadNumber = ""
    var strRead3 = ""
    
    var count = 0
    var len = 0
    var len3 = 0
    var mod3 = 0
    // Loại bỏ dấu phân cách nhóm
    strNumber = pStrNumeric.replacingOccurrences(of: ",", with: "")
    strNumber = pStrNumeric.replacingOccurrences(of: ".", with: "")
    
    // Loại bỏ số 0 đứng đầu
    let arr = Array(pStrNumeric)
    for i in 0..<arr.count {
        if (arr[i] == "0")
        {
            count += 1
        }
        else
        {
            break
        }
    }
    
    strNumber = String(strNumber.suffix(strNumber.count - count))
    print(strNumber)
    // Doc chuoi so
    len = strNumber.count
    // Dem bo so 3
    len3 = len / 3
    mod3 = len % 3
    
    // Neu do dai chuoi la 0 thi gan la so 0
    if (len == 0)
    {
        strNumber = "0"
        mod3 = 1
    }
    // Doc bo so dau tien
    let stringToConvert = String(strNumber.prefix(mod3))
    strRead3 = Len3ToString(stringToConvert) //.Substring(0, mod3)
    strReadNumber = strRead3
    
    for i in 0..<len3 {
        if (((3 * (len3 - i)) % 9 == 0) && (strReadNumber.count > 0))
        {
            strReadNumber += " tỷ"
        }
        if (strRead3.count > 0)
        {
            if ((3 * (len3 - i)) % 9 == 6)
            {
                strReadNumber += " triệu"
            }
            if (((3 * (len3 - i)) % 9 == 3))
            {
                strReadNumber += " nghìn"
            }
        }
        // Đọc chuỗi 3 kí tự
        let start = strNumber.index(strNumber.startIndex, offsetBy: mod3 + i * 3)
        let end = strNumber.index(start, offsetBy: 3)
        let range = start..<end
        let string3ToConvert = String(strNumber.substring(with: range))
        strRead3 = Len3ToString(string3ToConvert)//strNumber.Substring(mod3 + i * 3, 3))
        // Luu chuỗi còn lại
        //strNumber = strNumber.Substring(mod3 + i * 3)
        // Gán vào chuỗi kết quả đọc
        strReadNumber += strRead3
    }
    
    strReadNumber.removeFirst() // start space
    
    if let start = strReadNumber.first {
        strReadNumber.removeFirst()
        strReadNumber = start.uppercased() + strReadNumber
    }
    
    strReadNumber += " đồng"
    return strReadNumber //.Substring(1, 1).ToUpper() + strReadNumber.Substring(2)
}

func Len3ToString(_ pStrInt: String) -> String
{
    var strNumber = ""
    let len = pStrInt.count
    if ((pStrInt == "000") || (pStrInt == ""))
    {
        return strNumber
    }
    else
    {
        let arr = Array(pStrInt)
        switch (arr[0])
        {
        case "0":
            if (len == 3 || len == 1)
            {
                strNumber += " không"
            }
            break
        case "1":
            if (len == 2)
            {
                strNumber += " mười"
            }
            else
            {
                strNumber += " một"
            }
            break
        case "2":
            strNumber += " hai"
            break
        case "3":
            strNumber += " ba"
            break
        case "4":
            strNumber += " bốn"
            break
        case "5":
            strNumber += " năm"
            break
        case "6":
            strNumber += " sáu"
            break
        case "7":
            strNumber += " bẩy"
            break
        case "8":
            strNumber += " tám"
            break
        case "9":
            strNumber += " chín"
            break
        default:
            break
        }
        if (len == 3)
        {
            // hàng Trăm
            strNumber += " trăm"
        }
        if (len == 2)
        {
            if ((arr[0] != "0") && (arr[0] != "1"))
            {
                strNumber += " mươi"
            }
        }
        
        // Hàng Chục
        if (len >= 2)
        {
            switch (arr[1])
            {
            case "1":
                if (len == 3)
                {
                    strNumber += " mười"
                }
                if ((len == 2) && (arr[0] != "1"))
                {
                    strNumber += " mốt"
                }
                if ((len == 2) && (arr[0] == "1"))
                {
                    strNumber += " một"
                }
                break
            case "2":
                strNumber += " hai"
                break
            case "3":
                strNumber += " ba"
                break
            case "4":
                //if (len == 2)
                //{
                //    strNumber += " tư"
                //}
                //else
                //{
                strNumber += " bốn"
                //}
                break
            case "5":
                if (len == 2)
                {
                    strNumber += " lăm"
                }
                else
                {
                    strNumber += " năm"
                }
                break
            case "6":
                strNumber += " sáu"
                break
            case "7":
                strNumber += " bẩy"
                break
            case "8":
                strNumber += " tám"
                break
            case "9":
                strNumber += " chín"
                break
            default:
                break
            }
            if (len == 3)
            {
                if ((arr[1] != "0") && (arr[1] != "1"))
                {
                    strNumber += " mươi"
                }
                if ((arr[1] == "0") && (arr[2] != "0"))
                {
                    strNumber += " linh"
                }
            }
        }
        // Hàng đơn vị
        if (len == 3)
        {
            switch (arr[2])
            {
            case "1":
                if (arr[1] != "0" && arr[1] != "1")
                {
                    strNumber += " mốt"
                }
                else
                {
                    strNumber += " một"
                }
                break
            case "2":
                strNumber += " hai"
                break
            case "3":
                strNumber += " ba"
                break
            case "4":
                //if ((arr[1] != "0") && (arr[1] != "1"))
                //{
                //    strNumber += " tư"
                //}
                //else
                //{
                strNumber += " bốn"
                //}
                break
            case "5":
                if (arr[1] != "0")
                {
                    strNumber += " lăm"
                }
                else
                {
                    strNumber += " năm"
                }
                break
            case "6":
                strNumber += " sáu"
                break
            case "7":
                strNumber += " bẩy"
                break
            case "8":
                strNumber += " tám"
                break
            case "9":
                strNumber += " chín"
                break
            default:
                break
            }
        }
        
        return strNumber
    }
}

print(NumericIntToString("7555"))
print(NumericIntToString("73243555500"))
print(NumericIntToString("097677444533300"))
print(NumericIntToString("24"))
print(NumericIntToString("13"))

print(NumericIntToString("13000000"))
print(NumericIntToString("468"))
print(NumericIntToString("4680382"))
print(NumericIntToString("0"))
print(NumericIntToString("1005000"))
print(NumericIntToString("902"))
print(NumericIntToString("406000"))
print(NumericIntToString("1050010"))
print(NumericIntToString("25000"))
print(NumericIntToString("250000"))
print(NumericIntToString("1050003"))
print(NumericIntToString("100051003"))
print(NumericIntToString("100011003"))

print(NumericIntToString("1003342332232"))
